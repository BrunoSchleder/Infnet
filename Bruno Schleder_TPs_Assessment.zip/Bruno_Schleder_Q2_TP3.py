#Quest�o 2

#Informe a idade: 25
#Tem obriga��o de votar.
def obrigacao_votar():
  idade = int(input("Informe a Idade "))
  while idade <= 0:
    print("Idade Inv�lida")
    idade = int(input("Informe a Idade"))
  

#Informe a idade: 75
#N�o tem obriga��o de votar.
  if idade >= 16 and idade < 18 or idade > 70:
    print("Voto Facultativo")

#Informe a idade: 12
#N�o tem direito a voto.
  elif idade <16:
    print("N�o Pode Votar")
  else:
    print("Voto Obrigat�rio")

obrigacao_votar()

