#Quest�o 3

#Informe nome do 1� participante: Zefr�nio
#Informe nota do 1� participante: 8.5
#Informe nome do 2� participante: Oli�de
#Informe nota do 2� participante: 6.0
#Informe nome do 3� participante: Xonotr�nfila
#Informe nota do 3� participante: 7.8
#Informe nome do 4� participante: Carb�ncleo
#Informe nota do 4� participante: 8.6
#Informe nome do 5� participante: Zeugma
#Informe nota do 5� participante: 9.4
#O(a) vencedor(a) foi Zeugma com nota 9.4!

def escolhe_vencedor():
  for i in range(5):
    nome = input(f"Informe o nome do {i+1}� participante: ")
    nota = float(input(f"Informe a nota do {i+1}� participante: "))
    
    if i == 0 or nota > nota_vencedor:
      nome_vencedor = nome
      nota_vencedor = nota
    
  print(f"O vencedor foi {nome_vencedor} e com nota {nota_vencedor}")

escolhe_vencedor()