#Quest�o 1

#Informe o valor total do consumo: R$ 100.00
def calcula_taxa():
  consumo = float(input("Valor Total do Consumo R$ "))

#Informe o total de pessoas: 2
  numero = int(input("Total de Pessoas "))
  while numero < 1:
    print("digite um valor v�lido")
    numero = int(input("Total de Pessoas "))

#Informe o percentual do servi�o, entre 0 e 100: 10
  taxa = int(input("Informe o Percentual de Servi�o "))
  while taxa < 0 or taxa  > 100:
    print("digite um valor v�lido")
    taxa = int(input("Informe o Percentual de Servi�o "))

#O valor total da conta, com a taxa de servi�o, ser� de R$ 110,00.
  total_conta = round(consumo * (1 + taxa/100), 2)

#Dividindo a conta por 2 pessoa(s), cada pessoa dever� pagar R$ 55,00.
  divisao = round(total_conta / numero, 2)
  conta_real = numero * divisao

  print(f"O valor da conta por pessoa � de {divisao}")
  print(conta_real)

calcula_taxa()

